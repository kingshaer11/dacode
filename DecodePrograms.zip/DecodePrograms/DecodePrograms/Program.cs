﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;
using System.Configuration;
using System.Security.Cryptography;
using System.Reflection;
using System.Collections;

namespace DecodePrograms
{
    public class Program
    {
        static void Main()
        {
            var sourceDirectory = ConfigurationManager.AppSettings.Get("sourceDirectory");
            var targetDirectory = ConfigurationManager.AppSettings.Get("targetDirectory");

            DirectoryInfo sourceDircetory = new DirectoryInfo(sourceDirectory);
            DirectoryInfo targetDircetory = new DirectoryInfo(targetDirectory);
/*------------------------------------------------------------------------------------------------------------------*/
            if (sourceDirectory == "" || sourceDirectory == "C:\\" || sourceDirectory == "D:\\")
            {
                string source1 = @"C:\DeCode\";
               // string path2 = Path.Combine(path1, "test");
                Directory.CreateDirectory(source1);
                sourceDirectory = "" + source1 + "";
                Environment.Exit(0);
            }

            if (!sourceDircetory.Exists)
            {
                string source2 = @"C:\DeCode\";
                // string path2 = Path.Combine(path1, "test");

                Directory.CreateDirectory(source2);
                sourceDirectory = "" + source2 + "";
                Environment.Exit(0);
            }
            int count = sourceDircetory.GetFiles().Length;

/*------------------------------------------------------------------------------------------------------------------*/

            if (targetDirectory == "" || targetDirectory == "C:\\" || targetDirectory == "D:\\")
            {
                string target1 = @"C:\EnCode\";
                //string target2 = Path.Combine(target1, "test");

                Directory.CreateDirectory(target1);
                targetDirectory = "" + target1 + "";
                Environment.Exit(0);
            }
            if (targetDircetory.Exists)
            {
                foreach (FileInfo file in targetDircetory.GetFiles())
                {
                    file.Delete();
                }
                foreach (DirectoryInfo dir in targetDircetory.GetDirectories())
                {
                    dir.Delete(true);
                }
            }
/*------------------------------------------------------------------------------------------------------------------*/

            CopyAll(sourceDircetory, targetDircetory);
        }
        public static void CopyAll(DirectoryInfo source, DirectoryInfo target)
        {
            string fileName = "scrdec18";
            FileInfo f = new FileInfo(fileName);
            string Decode = f.FullName;

            Directory.CreateDirectory(target.FullName);

            foreach (FileInfo fi in source.GetFiles())
            {
                if (fi.Extension == ".inc" || fi.Extension == ".INC" || fi.Extension == ".ASP" || fi.Extension == ".asp")
                {
                    Process process = new Process();
                    process.StartInfo.FileName = "cmd.exe";
                    process.StartInfo.CreateNoWindow = true;
                    process.StartInfo.RedirectStandardInput = true;
                    process.StartInfo.RedirectStandardOutput = true;
                    process.StartInfo.UseShellExecute = false;
                    process.Start();
                    process.StandardInput.WriteLine("cd \\");
                    process.StandardInput.WriteLine("" + Decode + " " + fi.FullName + " " + target.FullName + "\\" + fi.Name + "");
                    Console.WriteLine(@"Decode {0}\{1}", target.FullName, fi.Name);
                }
                else
                {
                    Console.WriteLine(@"Copying {0}\{1}", target.FullName, fi.Name);
                    fi.CopyTo(Path.Combine(target.FullName, fi.Name.Replace("" + fi + "", "" + fi + "")), true);
                }
            }
            foreach (DirectoryInfo diSourceSubDir in source.GetDirectories())
            {
                DirectoryInfo nextTargetSubDir =
                target.CreateSubdirectory(diSourceSubDir.Name);
                CopyAll(diSourceSubDir, nextTargetSubDir);
            }
        }
    }
}